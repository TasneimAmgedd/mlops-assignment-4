import tensorflow as tf
from tensorflow.keras import layers
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
import random

# seeds and deterministic ops
SEED = 42
tf.random.set_seed(SEED)
np.random.seed(SEED)
random.seed(SEED)
os.environ['PYTHONHASHSEED'] = str(SEED)
os.environ['TF_DETERMINISTIC_OPS'] = '1'
os.environ['TF_CUDNN_DETERMINISTIC'] = '1'

print("TensorFlow version:", tf.__version__)

(x_train, _), (_, _) = tf.keras.datasets.mnist.load_data()
x_train = x_train / 255.0
x_train = x_train.reshape(-1, 28, 28, 1)

generator = tf.keras.Sequential([
    layers.Dense(128, activation="relu", input_shape=(100,)),
    layers.Dense(28*28, activation="sigmoid"),
    layers.Reshape((28, 28, 1))
])

discriminator = tf.keras.Sequential([
    layers.Flatten(input_shape=(28,28,1)),
    layers.Dense(128, activation="relu"),
    layers.Dense(1, activation="sigmoid")
])

cross_entropy = tf.keras.losses.BinaryCrossentropy()
generator_optimizer = tf.keras.optimizers.Adam(1e-4)
discriminator_optimizer = tf.keras.optimizers.Adam(1e-4)

def train_step(images):
    noise = tf.random.normal([images.shape[0], 100], seed=SEED)
    with tf.GradientTape() as gen_tape, tf.GradientTape() as disc_tape:
        generated_images = generator(noise, training=True)
        real_output = discriminator(images, training=True)
        fake_output = discriminator(generated_images, training=True)
        gen_loss = cross_entropy(tf.ones_like(fake_output), fake_output)
        disc_loss = (cross_entropy(tf.ones_like(real_output), real_output) +
                     cross_entropy(tf.zeros_like(fake_output), fake_output))
    gradients_of_generator = gen_tape.gradient(gen_loss, generator.trainable_variables)
    gradients_of_discriminator = disc_tape.gradient(disc_loss, discriminator.trainable_variables)
    generator_optimizer.apply_gradients(zip(gradients_of_generator, generator.trainable_variables))
    discriminator_optimizer.apply_gradients(zip(gradients_of_discriminator, discriminator.trainable_variables))
    return gen_loss, disc_loss

EPOCHS = 1
BATCH_SIZE = 64
dataset = tf.data.Dataset.from_tensor_slices(x_train).shuffle(60000, seed=SEED).batch(BATCH_SIZE)

for epoch in range(EPOCHS):
    gen_loss_epoch = 0
    disc_loss_epoch = 0
    num_batches = 0
    for batch in dataset:
        gen_loss, disc_loss = train_step(batch)
        gen_loss_epoch += gen_loss
        disc_loss_epoch += disc_loss
        num_batches += 1
    print(f"Epoch {epoch+1}: Average Generator loss: {gen_loss_epoch/num_batches:.4f}, Average Discriminator loss: {disc_loss_epoch/num_batches:.4f}")

x_flat = x_train.reshape(x_train.shape[0], -1)
df = pd.DataFrame(x_flat)
df.to_csv("mnist_data.csv", index=False)

noise = tf.random.normal([1, 100], seed=SEED)
generated_image = generator(noise, training=False)

plt.imshow(generated_image[0, :, :, 0], cmap='gray')
plt.axis('off')
plt.show()